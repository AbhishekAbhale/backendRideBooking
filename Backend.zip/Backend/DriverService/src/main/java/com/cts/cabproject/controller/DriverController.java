package com.cts.cabproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.cabproject.entity.Driver;


import com.cts.cabproject.service.DriverService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class DriverController {
    
    @Autowired
    private DriverService driverService;
    
    // Driver Registration - Public endpoint (no authentication required)
    @PostMapping("/register")
    public ResponseEntity<Driver> registerDriver(@RequestBody Driver driver) {
        // Auto-verify new drivers and set them as available
        driver.setVerified(true);
        driver.setAvailable(true);
        return ResponseEntity.ok(driverService.registerDriver(driver));
    }
    
    @GetMapping("getProfileDetails/{DriverId}")
    public ResponseEntity<Driver> profileView(@PathVariable Long DriverId){
        return ResponseEntity.ok(driverService.searchByID(DriverId));
    }
    
    @PostMapping("/update")
    public ResponseEntity<Driver> updateProfile(@RequestBody Driver driver){
        return ResponseEntity.ok(driverService.updateProfile(driver));
    }
    
//    @PostMapping("/request")
//    public ResponseEntity<String> sendRideRequest(@RequestBody RideRequestDTO request) {
//        String response = driverService.sendRideRequestToDrivers(request);
//        return ResponseEntity.ok(response);
//    }
//  
    // Protected endpoints - require JWT authentication
    @PreAuthorize("isAuthenticated()")
    @PatchMapping("/driver/{driverId}/{isAvailable}")
    public ResponseEntity<String> toggleAvailability(@PathVariable Long driverId, @PathVariable boolean isAvailable) {
        driverService.updateAvailability(driverId, isAvailable);
        return ResponseEntity.ok("Availability updated");
    }
    
    
//    @PostMapping("/create")
//    public ResponseEntity<RideRequestDTO> createRide(@RequestBody RideRequestDTO request) {
//    	RideRequestDTO savedRequest = driverService.createRideRequest(request);
//        return ResponseEntity.ok(savedRequest);
//    }
//
//    @PatchMapping("/accept/{requestId}/{driverId}")
//    public ResponseEntity<RideRequestDTO> acceptRide(@PathVariable Long requestId, @PathVariable Long driverId) {
//    	RideRequestDTO updatedRequest = driverService.acceptRequest(requestId, driverId);
//        return ResponseEntity.ok(updatedRequest);
//    }
//    
  
    
    
}


