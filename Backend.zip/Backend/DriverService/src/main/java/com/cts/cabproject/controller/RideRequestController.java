package com.cts.cabproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.cts.cabproject.entity.RideRequest;
import com.cts.cabproject.service.RideRequestService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/ride")
public class RideRequestController {

    @Autowired
    private RideRequestService rideRequestService;

    @PostMapping("/create")
    public ResponseEntity<RideRequest> createRide(@RequestBody RideRequest request) {
    	RideRequest savedRequest = rideRequestService.createRideRequest(request);
        return ResponseEntity.ok(savedRequest);
    }

    @PatchMapping("/accept/{requestId}/{driverId}")
    public ResponseEntity<RideRequest> acceptRide(@PathVariable Long requestId, @PathVariable Long driverId) {
        RideRequest updatedRequest = rideRequestService.acceptRequest(requestId, driverId);
        return ResponseEntity.ok(updatedRequest);
    }
    
    @GetMapping("/user/{userId}/confirmed")
    public ResponseEntity<List<RideRequest>> getConfirmedRequestsByUser(@PathVariable Long userId) {
        List<RideRequest> confirmedRequests = rideRequestService.getConfirmedRequestsByUserId(userId);
        return ResponseEntity.ok(confirmedRequests);
    }


    @GetMapping("/pending")
    public ResponseEntity<List<RideRequest>> getPendingRides() {
        List<RideRequest> pendingRides = rideRequestService.getPendingRides();
        return ResponseEntity.ok(pendingRides);
    }


    @GetMapping("/all")
    public ResponseEntity<Object> getAllRequests() {
        return ResponseEntity.ok(rideRequestService.getAllRequests());
    }
    
    @GetMapping("/driver/{driverId}/confirmed")
    public ResponseEntity<List<RideRequest>> getConfirmedRidesByDriver(@PathVariable Long driverId) {
        List<RideRequest> confirmedRides = rideRequestService.getConfirmedRidesByDriverId(driverId);
        return ResponseEntity.ok(confirmedRides);
    }

    @GetMapping("/user/{userId}/request/{requestId}/confirmed")
    public ResponseEntity<RideRequest> getConfirmedRideForUser(
            @PathVariable Long userId,
            @PathVariable Long requestId) {
        RideRequest ride = rideRequestService.getConfirmedRideForUser(requestId, userId);
        return ResponseEntity.ok(ride);
    }



    
}

