package com.cts.cabproject.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RideAcceptanceResponseDTO {
    private RideRequest rideRequest;
    private String message;
}
