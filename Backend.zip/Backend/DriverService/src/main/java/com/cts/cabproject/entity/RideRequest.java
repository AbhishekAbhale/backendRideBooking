package com.cts.cabproject.entity;



import jakarta.persistence.*;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "RideReq")
public class RideRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long requestId;

    @Column(nullable = false)
    private String origin;

    @Column(nullable = false)
    private String destination;

    @Column(nullable = false)
    private double amount;

    @Column(nullable = false)
    private String distance;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private boolean isAccepted = false;

    @Column(nullable = true)
    private Long acceptedDriverId = null;
    
    @Column(nullable = false)
    private String status = "PENDING";
}

//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Data
//@Entity
//@Table(name = "RideRequests")
//public class RideRequest {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long requestId;
//
//    private Long userId;
//    private Long driverId; // nullable until accepted
//    private String origin;
//    private String destination;
//    private double amount;
//    private String distance;
//    private String status; // e.g., "PENDING", "ACCEPTED", "REJECTED"
//	public void setAcceptedDriverId(Long driverId2) {
//		// TODO Auto-generated method stub
//		
//	}
//
//    
//}
