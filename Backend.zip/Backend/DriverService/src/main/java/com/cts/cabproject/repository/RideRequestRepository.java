package com.cts.cabproject.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.cabproject.entity.RideRequest;

@Repository
public interface RideRequestRepository extends JpaRepository<RideRequest, Long> {
//    List<RideRequest> findByStatus(String status);
//
//	Optional<RideRequest> findById(Long requestId);
//
//	RideRequest save(RideRequest request);
	List<RideRequest> findByStatus(String status);

	List<RideRequest> findByUserId(Long userId);
	
	//List<RideRequest> findByUserIdAndStatus(Long userId, String status);
	
	List<RideRequest> findByAcceptedDriverIdAndStatus(Long driverId, String status);

	List<RideRequest> findByRequestIdAndUserIdAndIsAcceptedTrueAndStatus(Long requestId, Long userId, String status);


}

