package com.cts.cabproject.service;

import java.util.List;

import com.cts.cabproject.entity.Driver;


public interface DriverService {
    
    Driver registerDriver(Driver driver);
    
    Driver searchByID(Long driverId);
    
    Driver updateProfile(Driver driver);
    
    void deleteDriver(Long driverId);
    
    List<Driver> getAllDrivers(int pageNo, int pageSize, String sortBy);
    
    void updateAvailability(Long driverId, boolean isAvailable);
    
    Driver validateDriverLogin(String email, String password);
    
    Driver findDriverByEmailAndPassword(String email, String passwordHash);

//	String sendRideRequestToDrivers(RideRequestDTO request);
//
//	RideRequestDTO acceptRequest(Long requestId, Long driverId);
//
//	RideRequestDTO createRideRequest(RideRequestDTO request);

	
}
