package com.cts.cabproject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cts.cabproject.entity.Driver;
import com.cts.cabproject.repository.DriverRepository;

@Service
public class DriverServiceImpl implements DriverService {
    
    @Autowired
    private DriverRepository driverRepository;
    
    @Override
    public Driver registerDriver(Driver driver) {
        // Check if email already exists
        if (driverRepository.existsByEmail(driver.getEmail())) {
            throw new RuntimeException("Driver with this email already exists");
        }
        
        // Check if license number already exists
        if (driverRepository.existsByLicenseNumber(driver.getLicenseNumber())) {
            throw new RuntimeException("Driver with this license number already exists");
        }
        
        return driverRepository.save(driver);
    }
    
    @Override
    public Driver searchByID(Long driverId) {
        return driverRepository.findById(driverId)
                .orElseThrow(() -> new RuntimeException("Driver not found with id: " + driverId));
    }
    
    @Override
    public Driver updateProfile(Driver driver) {
        Driver existingDriver = searchByID(driver.getDriverId());
        
        // Update fields
        existingDriver.setFullName(driver.getFullName());
        existingDriver.setPhoneNumber(driver.getPhoneNumber());
        existingDriver.setVehicleColor(driver.getVehicleColor());
        existingDriver.setPhoneNumber(driver.getPhoneNumber());
        existingDriver.setCapacity(driver.getCapacity());
        
        return driverRepository.save(existingDriver);
    }
    
    @Override
    public void deleteDriver(Long driverId) {
        Driver driver = searchByID(driverId);
        driverRepository.delete(driver);
    }
    
    @Override
    public List<Driver> getAllDrivers(int pageNo, int pageSize, String sortBy) {
        Pageable pageable = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
        Page<Driver> driverPage = driverRepository.findAll(pageable);
        return driverPage.getContent();
    }
    
    @Override
    public void updateAvailability(Long driverId, boolean isAvailable) {
        Driver driver = searchByID(driverId);
        driver.setAvailable(isAvailable);
        driverRepository.save(driver);
    }
    
    @Override
    public Driver validateDriverLogin(String email, String password) {
        Optional<Driver> driverOpt = driverRepository.findByEmailAndPassword(email, password);
        return driverOpt.orElse(null);
    }
    
    @Override
    public Driver findDriverByEmailAndPassword(String email, String passwordHash) {
        Optional<Driver> driverOpt = driverRepository.findByEmailAndPassword(email, passwordHash);
        return driverOpt.orElse(null);
    }
    
  
//    @Override
//    public String sendRideRequestToDrivers(RideRequestDTO request) {
//        List<Driver> availableDrivers = driverRepository.findByIsAvailableTrue();
//
//        for (Driver driver : availableDrivers) {
//            // Simulate sending notification (e.g., via email, push, or message queue)
//            System.out.println("Sending ride request to driver: " + driver.getFullName());
//            System.out.println("Details: Origin=" + request.getOrigin() +
//                               ", Destination=" + request.getDestination() +
//                               ", Distance=" + request.getDistance() +
//                               ", Amount=" + request.getAmount() +
//                               ", User ID=" + request.getUserId());
//        }
//
//        return "Ride request sent to " + availableDrivers.size() + " available drivers.";
//    }
//
//    @Override
//    public RideRequestDTO createRideRequest(RideRequestDTO request) {
//    	RideRequestDTO savedRequest = driverRepository.save(request);
//
//        // Notify all available drivers (you can replace this with actual notification logic)
//        List<Driver> availableDrivers = driverRepository.findAll()
//            .stream()
//            .filter(Driver::isAvailable)
//            .filter(Driver::isVerified)
//            .toList();
//
//        for (Driver driver : availableDrivers) {
//            System.out.println("Notification sent to driver: " + driver.getFullName() +
//                " for request ID: " + savedRequest.getRequestId());
//        }
//
//        return savedRequest;
//    }
//
//    @Override
//    public RideRequestDTO acceptRequest(Long requestId, Long driverId) {
//    	Driver request = driverRepository.findById(requestId)
//            .orElseThrow(() -> new RuntimeException("Request not found"));
//
//        request.setAccepted(true);
//        request.setAcceptedDriverId(driverId);
//        return driverRepository.save(request);
//    }

}
