package com.cts.cabproject.service;

import java.util.List;

import com.cts.cabproject.entity.RideRequest;

public interface RideRequestService {

	Object getAllRequests();

	RideRequest acceptRequest(Long requestId, Long driverId);

	RideRequest createRideRequest(RideRequest request);

	List<RideRequest> getRequestsByUserId(Long userId);

	List<RideRequest> getPendingRides();

	List<RideRequest> getConfirmedRequestsByUserId(Long userId);

	

	RideRequest getConfirmedRideForUser(Long requestId, Long userId);

	List<RideRequest> getConfirmedRidesByDriverId(Long driverId);

	List<RideRequest> findByRequestIdAndUserIdAndIsAcceptedTrueAndStatus(Long requestId, Long userId, String status);

	


}
