package com.cts.cabproject.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.cts.cabproject.entity.Driver;
import com.cts.cabproject.entity.RideRequest;
import com.cts.cabproject.repository.DriverRepository;
import com.cts.cabproject.repository.RideRequestRepository;

@Service
public class RideRequestServiceImpl implements RideRequestService {

    @Autowired
    private RideRequestRepository rideRequestRepository;

    @Autowired
    private DriverRepository driverRepository;
 
    @Override
    public RideRequest createRideRequest(RideRequest request) {
        request.setStatus("PENDING"); // Set initial status
        RideRequest savedRequest = rideRequestRepository.save(request);

        List<Driver> availableDrivers = driverRepository.findAll()
            .stream()
            .filter(Driver::isAvailable)
            .filter(Driver::isVerified)
            .toList();

        for (Driver driver : availableDrivers) {
            System.out.println("Notification sent to driver: " + driver.getFullName() +
                " for request ID: " + savedRequest.getRequestId());
        }

        return savedRequest;
    }

    @Override
    public RideRequest acceptRequest(Long requestId, Long driverId) {
        RideRequest request = rideRequestRepository.findById(requestId)
            .orElseThrow(() -> new RuntimeException("Request not found"));

        request.setAccepted(true);
        request.setAcceptedDriverId(driverId);
        request.setStatus("CONFIRMED"); // Update status on acceptance

        return rideRequestRepository.save(request);
    }


    @Override
    public List<RideRequest> getPendingRides() {
        return rideRequestRepository.findByStatus("PENDING");
    }
    
//    @Override
//    public List<RideRequest> getConfirmedRequestsByUserId(Long userId) {
//        return rideRequestRepository.findByUserIdAndStatus(userId, "CONFIRMED");
//    }

    @Override
    public List<RideRequest> getConfirmedRidesByDriverId(Long driverId) {
        return rideRequestRepository.findByAcceptedDriverIdAndStatus(driverId, "CONFIRMED");
    }

    @Override
    public RideRequest getConfirmedRideForUser(Long requestId, Long userId) {
        List<RideRequest> rides = rideRequestRepository
            .findByRequestIdAndUserIdAndIsAcceptedTrueAndStatus(requestId, userId, "CONFIRMED");

        if (rides.isEmpty()) {
            throw new RuntimeException("No confirmed ride found for this user and request ID");
        }

        return rides.get(0); // Assuming only one match is expected
    }


    


    
@Override
public Object getAllRequests() {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<RideRequest> getRequestsByUserId(Long userId) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<RideRequest> getConfirmedRequestsByUserId(Long userId) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<RideRequest> findByRequestIdAndUserIdAndIsAcceptedTrueAndStatus(Long requestId, Long userId,
		String status) {
	// TODO Auto-generated method stub
	return null;
}


}
